# Android Video Engine Integration Kit

এই ZIP-টি আপনার **Kotlin Android app-এ video playback/edit-preview যোগ করার integration pack**। এটি কোনো “সব codec চালায়” এমন prebuilt universal player নয়, এবং এটি আপনার app repo-র পরিবর্তে standalone app-ও নয়। আপনার repo-তে থাকা coding agent-কে `AGENT_TASK_EN.md` দিন; সে বিদ্যমান app দেখে ফাইলগুলো ঠিক জায়গায় বসাবে।

## ZIP-এ কী আছে

- `AGENT_TASK_EN.md` — repo-linked coding agent-এর জন্য কপি/ব্যবহারযোগ্য integration নির্দেশনা।
- `android/gradle-dependencies.txt` — AndroidX Media3 dependency উদাহরণ।
- `android/src/main/kotlin/com/example/videoengine/` — Media3 player controller-এর ছোট Kotlin নমুনা; `com.example`-কে আপনার app namespace দিয়ে বদলাতে হবে।
- `docs/FORMAT_SUPPORT.md` — কোন format-কে কীভাবে বাস্তবসম্মতভাবে লক্ষ্য করবেন।
- `docs/LICENSING.md` — Media3, LibVLC, MotionCam decoder, FFmpeg ও codec-license সতর্কতা।
- `docs/EXPORT_AND_TIMELINE.md` — timeline আপনি নিজে বানালে preview/export কীভাবে আলাদা রাখবেন।
- `tests/DEVICE_TEST_MATRIX.md` — device ও media test checklist।

## প্রস্তাবিত ভিত্তি

প্রথমে **Media3 ExoPlayer** দিয়ে প্রচলিত Android-compatible ভিডিও চালান; **Media3 Transformer** দিয়ে সমর্থিত trim/effect/export করুন। সব Media3 artifact একই version-এ রাখুন। ZIP-এ 1.11.1-কে research-time example হিসেবে ব্যবহার করা হয়েছে—আপনার app-এর Android Gradle Plugin, `minSdk` ও dependency constraints দেখে coding agent যেন compatibility যাচাই করে।

যে ফাইল Media3/device decoder দিয়ে decode হয় না, সেটির জন্য coding agent আগে error ও sample file পরীক্ষা করুক। **LibVLC**-কে চাইলে playback-only fallback হিসেবে মূল্যায়ন করা যায়, কিন্তু সেটি আপনার timeline editor বা একই edit/export pipeline-এর বদলি নয়। `.mcraw` support চাইলে সেটি আলাদা RAW decoder/rendering path—Media3/LibVLC-তে শুধু dependency যোগ করলেই হবে না।

## “সব ফরম্যাট” সম্পর্কে জরুরি কথা

কোনো একটি library-কে দিয়ে আক্ষরিক অর্থে সব container, codec, bit depth, HDR profile, RAW format, DRM ও camera-specific file চালানো নিশ্চিত করা যায় না। Format support device, Android version, hardware decoder, file-এর ভেতরের codec, library build configuration, license এবং patent restrictions-এর ওপর নির্ভর করে। তাই app-এ “সব ফরম্যাট supported” না লিখে **capability check + স্পষ্ট unsupported-format error** রাখুন।

## এই ZIP-এ যা নেই

- `.aar`/`.so` binary, FFmpeg binary বা bundled codec library নেই। এগুলো app-এর ABI/Android version/build এবং নির্বাচিত component/license না জেনে এক ZIP-এ নিরাপদে দেওয়া যায় না। Media3-কে Gradle/Maven থেকে নেওয়া উচিত; native library হলে coding agent-কে আপনার app অনুযায়ী build ও notices যোগ করতে হবে।
- আপনার app-এর timeline UI নেই—আপনি বলেছেন সেটি নিজে বানাবেন।
- `.mcraw`, ProRes/DNxHR, সব RAW বা সব HDR format-এর নিশ্চয়তা নেই। এগুলো আলাদা proof-of-concept ও device testing চায়।

## দ্রুত ব্যবহার

1. ZIP extract করুন।
2. `AGENT_TASK_EN.md` এবং `docs/` আপনার repo-linked coding agent-কে দিন।
3. Agent-কে বলুন আগে app-এর Gradle/Compose-or-Views/minSdk/player implementation পরীক্ষা করতে; তারপর কেবল দরকারি ফাইল পরিবর্তন করতে।
4. আপনার আসল failing video এবং Logcat error দিয়ে test করান।
5. Build APK-তে third-party license/NOTICE এবং format limitation যাচাই করুন।
