# Timeline-owned-by-the-app integration notes

The user's timeline UI remains outside this kit. Keep the timeline model separate from the playback engine and from the final encoder.

## Suggested neutral clip fields

- Stable clip ID.
- Source URI plus MIME/track metadata; preserve SAF access where required.
- Source in/out time in microseconds or another single documented integer timebase.
- Timeline start/duration and track/layer ID.
- Speed, rotation, crop, volume, mute state and supported per-clip effects.
- Edit history/undo data in the app's own project model, not in the player instance.

Use integer time values rather than accumulating floating-point seconds, and define how edits snap to frames. The player should render the current timeline position; the export adapter should consume the same edit model where possible.

## Preview versus export

- ExoPlayer handles playback and seeking of supported media. It is not a timeline UI.
- Media3 Transformer can export supported edits, but the app must validate each operation and source format. Do not represent every preview effect as guaranteed to match every export.
- Media3 compositions have documented feature limits; in particular, crossfading audio/video tracks is not currently supported in the multi-asset composition docs. A more advanced overlapping-track compositor may be separate work.
- If a source cannot be decoded by the chosen edit/export path, either show a clear unsupported state or build a proxy/transcode path. A LibVLC-only preview is not proof that Transformer can export the same source.
- Exports should run off the UI thread, report progress, support cancellation where available, and clean up temporary files on failure.
