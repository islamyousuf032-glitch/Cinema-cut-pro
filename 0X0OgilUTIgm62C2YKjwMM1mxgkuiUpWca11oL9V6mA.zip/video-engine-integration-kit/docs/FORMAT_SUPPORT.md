# Practical format-support policy

“সব ফরম্যাট” একটি যাচাইযোগ্য engineering target নয়। একই `.mp4` container-এও আলাদা codec/profile/bit depth থাকতে পারে; কোনটি চলে তা Android version, device hardware decoder, chosen Media3 modules and encoder path-এর ওপর নির্ভর করে। Extension দেখে support নিশ্চিত করবেন না।

| Target | Initial recommendation | Important limitation |
|---|---|---|
| MP4 + H.264 + AAC | Baseline device-test target with Media3 ExoPlayer/Transformer | Test actual sample and export on target Android versions. |
| MP4/MOV + HEVC/H.265 | Test per device and profile | Hardware decoder, bit depth, HDR profile and encoder support vary. |
| MKV/WebM/AVI | Test container and contained tracks independently | Container may open while its video/audio codec or track layout is unsupported. |
| VP9/AV1, 10-bit, HDR | Explicit capability tests | Hardware/software decoder, GPU effects and export support are not universal. |
| ProRes / DNxHR / unusual professional codecs | Separate proof-of-concept | Do not claim they are editable on every Android device. Proxy/transcode workflow may be needed. |
| MotionCam `.mcraw` | Separate native decoder and rendering pipeline | Use the MCRAW decoder as a starting point; generic ExoPlayer/LibVLC is not a direct `.mcraw` editor. |
| DRM-protected media | Treat separately | DRM playback and export/editing rights are different; do not try to bypass protection. |

## Backend policy

1. Start with Media3 for standard media and editing/export operations Media3 actually supports.
2. Record real playback errors and maintain a device/format capability matrix.
3. Add LibVLC only if target samples demonstrate a playback gap. Do not imply LibVLC playback means the same media is editable/exportable by Media3 Transformer.
4. For MCRAW/RAW, create a separate `RawMediaBackend` and test frame decode, color conversion, audio sync, scrubbing and export. Do not route `.mcraw` to a conventional player and report a generic “video error.”
5. Return a clear unsupported-format message and suggest a supported proxy/transcode workflow when appropriate.
