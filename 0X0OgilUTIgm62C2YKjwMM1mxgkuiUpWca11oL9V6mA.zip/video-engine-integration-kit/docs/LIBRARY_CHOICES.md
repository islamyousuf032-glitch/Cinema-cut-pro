# Library choice summary

## 1. AndroidX Media3 — default for standard Android media

- ExoPlayer: standard Android playback, seeking, state/error handling and custom UI integration.
- Transformer: export/transformation features for supported formats and device capabilities.
- Good first implementation for a native Kotlin editor where the app owns the timeline.
- Not a universal codec guarantee and not a ready-made nonlinear editor UI.

Official repository: https://github.com/androidx/media
Official playback docs: https://developer.android.com/media/media3/exoplayer
Transformer docs: https://developer.android.com/media/media3/transformer

## 2. LibVLC — optional playback compatibility backend

- Consider only when real test media fails in the primary playback path.
- It is an embedded playback engine, not the app's timeline/export system.
- Native library size, ABI coverage, lifecycle and license compliance require review.

Official Android repository: https://github.com/videolan/vlc-android

## 3. MotionCam MCRAW decoder — optional RAW path

- Use only if `.mcraw` files are actual product inputs.
- Decoder library: https://github.com/mirsadm/motioncam-decoder
- It needs a separate Android native/GPU rendering, timeline preview and export plan.

## 4. GStreamer Editing Services — evaluate for deeper generic NLE needs

- Exposes timeline/layer/track concepts and preview/render pipelines.
- More native integration/build/plugin work than a simple Media3 player setup; it does not supply the app's editor UI.
- It does not remove the need for a dedicated `.mcraw` decoder.

Docs: https://gstreamer.freedesktop.org/documentation/gst-editing-services/
