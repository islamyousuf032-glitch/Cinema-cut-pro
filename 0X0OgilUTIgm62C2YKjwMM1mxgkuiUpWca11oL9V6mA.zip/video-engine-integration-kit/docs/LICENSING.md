# Third-party component and codec notes

This bundle contains integration guidance and a small sample controller; it does not vendor third-party source or native binaries. The repo-linked agent must inspect the exact version and build configuration that it adds.

- **AndroidX Media3**: Apache-2.0. Preserve required copyright/license notices for the version distributed.
- **LibVLC for Android**: the LibVLC engine is LGPL-2.1; the full VLC for Android app is GPL-2-or-later (the upstream repo notes Android app licensing details). Do not confuse the engine license with the full app license. Check the exact AAR, bundled modules, and LGPL obligations before shipping.
- **MotionCam `motioncam-decoder`**: its GitHub repository identifies Apache-2.0. Preserve its license/notice and check any bundled third-party components when building it.
- **`motioncam-app/motioncam-player`**: the repository license is GPL-3.0 and the project is marked work-in-progress. It is not the same thing as the separately licensed decoder library. Avoid copying/linking its app code into a proprietary app without legal review.
- **FFmpeg**: the codebase is primarily LGPL with optional GPL components; the exact configure/build options and included codecs/filters matter. A wrapper does not remove these requirements. Check the current upstream status before selecting a wrapper; avoid assuming an old FFmpegKit tutorial/package is maintained.
- **Codec patents/technology rights**: source-code license and patent/codec rights are separate questions. Check the codecs and distribution regions relevant to the product.

This is engineering guidance, not legal advice. Keep a third-party notices file and the exact dependency/build configuration with every release.
