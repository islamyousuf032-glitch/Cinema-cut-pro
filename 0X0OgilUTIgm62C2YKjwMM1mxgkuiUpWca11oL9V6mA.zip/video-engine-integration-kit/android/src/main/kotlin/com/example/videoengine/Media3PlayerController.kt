package com.example.videoengine

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/**
 * Minimal playback adapter for an existing Kotlin Android app.
 *
 * UI note: attach [player] to the app's existing PlayerView/Compose surface.
 * Create and call this object on the main thread, and call [release] when its owner is done.
 * This is only a playback controller; it is not a timeline, codec guarantee, or export engine.
 */
class Media3PlayerController(
    context: Context,
    private val onSnapshot: (PlayerSnapshot) -> Unit
) {
    val player: ExoPlayer = ExoPlayer.Builder(context.applicationContext).build()

    private var lastErrorCode: Int? = null
    private var lastErrorMessage: String? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                emitSnapshot()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                emitSnapshot()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                lastErrorCode = null
                lastErrorMessage = null
                emitSnapshot()
            }

            override fun onPlayerError(error: PlaybackException) {
                lastErrorCode = error.errorCode
                lastErrorMessage = error.message ?: "Media3 playback failed"
                emitSnapshot()
            }
        })
    }

    /**
     * Set a SAF/content/file/network URI. The caller is responsible for obtaining and,
     * where appropriate, persisting access to content:// URIs using the Storage Access Framework.
     */
    fun setSource(uri: Uri, mimeType: String? = null, autoPlay: Boolean = false) {
        lastErrorCode = null
        lastErrorMessage = null

        val builder = MediaItem.Builder().setUri(uri)
        if (!mimeType.isNullOrBlank()) {
            builder.setMimeType(mimeType)
        }

        player.setMediaItem(builder.build())
        player.prepare()
        player.playWhenReady = autoPlay
        emitSnapshot()
    }

    fun play() {
        player.play()
    }

    fun pause() {
        player.pause()
    }

    fun seekTo(positionMs: Long) {
        player.seekTo(positionMs.coerceAtLeast(0L))
    }

    fun setPlaybackSpeed(speed: Float) {
        require(speed.isFinite() && speed > 0f) { "Playback speed must be a finite value greater than zero." }
        player.playbackParameters = PlaybackParameters(speed)
    }

    fun setVolume(volume: Float) {
        require(volume.isFinite()) { "Volume must be finite." }
        player.volume = volume.coerceIn(0f, 1f)
    }

    fun release() {
        player.release()
    }

    private fun emitSnapshot() {
        val status = when (player.playbackState) {
            Player.STATE_BUFFERING -> PlaybackStatus.BUFFERING
            Player.STATE_READY -> PlaybackStatus.READY
            Player.STATE_ENDED -> PlaybackStatus.ENDED
            else -> PlaybackStatus.IDLE
        }

        val duration = player.duration.takeIf { it >= 0L }
        onSnapshot(
            PlayerSnapshot(
                status = status,
                isPlaying = player.isPlaying,
                positionMs = player.currentPosition.coerceAtLeast(0L),
                durationMs = duration,
                errorCode = lastErrorCode,
                errorMessage = lastErrorMessage
            )
        )
    }
}
