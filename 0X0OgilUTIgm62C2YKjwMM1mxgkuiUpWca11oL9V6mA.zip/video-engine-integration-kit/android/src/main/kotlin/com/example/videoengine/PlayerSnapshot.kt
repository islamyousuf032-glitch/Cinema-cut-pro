package com.example.videoengine

/**
 * UI-neutral playback state for the editor/timeline to observe.
 * Replace `com.example.videoengine` with the app's namespace when integrating.
 */
enum class PlaybackStatus {
    IDLE,
    BUFFERING,
    READY,
    ENDED
}

data class PlayerSnapshot(
    val status: PlaybackStatus,
    val isPlaying: Boolean,
    val positionMs: Long,
    val durationMs: Long?,
    val errorCode: Int? = null,
    val errorMessage: String? = null
)
