# Task for the repository-linked Android coding agent

You are editing an existing **Kotlin Android video-editing app**. The user will build the timeline UI themselves. Integrate a reliable playback/preview foundation into the existing app; do not replace the app, invent a new editor, or copy a complete video-editor repository.

## First inspect; do not guess

1. Inspect the repository before editing: Android Gradle Plugin, Gradle/Kotlin versions, `minSdk`, app namespace, UI toolkit (Compose or Views), current playback code, storage picker/URI flow, and current player/export errors.
2. Report those findings and identify the exact failure mode from the supplied sample video and Logcat. A player swap alone may not fix a URI grant, unsupported codec, surface/lifecycle, or memory problem.
3. Keep the implementation inside the existing project architecture. Do not rename packages, delete unrelated features, or replace the user's timeline.

## Playback architecture

- Use AndroidX Media3 ExoPlayer as the primary playback engine for standard Android-compatible media. Use the current stable Media3 version compatible with this repo; if using the bundle's research-time example, align every Media3 artifact to `1.11.1`.
- Add only the Media3 modules needed. `media3-exoplayer` and the UI module are for playback; add `media3-transformer` for supported export operations and `media3-effect` only if the effects APIs are used. If HLS/DASH is required, add the matching Media3 playback module; do not add streaming modules just for local editing.
- Implement or adapt a small playback abstraction/controller so the user's future timeline can command `setSource`, play, pause, seek/scrub, speed, volume, and listen for state/error updates without depending on UI details.
- Attach the player to the project's existing Compose or Views surface; do not create a second competing screen.
- Support SAF `content://` URIs. Preserve URI access where appropriate; do not assume every video is a filesystem path and do not request broad storage access unnecessarily.
- Handle lifecycle, release, audio focus where relevant, orientation/aspect ratio, buffering, and errors. Avoid leaking or repeatedly creating ExoPlayer instances during recomposition/navigation.
- Return a useful structured unsupported/playback error (MIME/URI context and underlying player error) rather than silently failing.

## Editing/export scope (timeline UI is out of scope)

- Do not build the timeline UI; the user owns it.
- Keep source clip data and edit parameters independent of the player: source URI, trim in/out, playback speed, rotation/crop, and supported effects. The user's future timeline should be able to supply this state to preview/export adapters.
- Use Media3 Transformer only for operations verified to be supported by the chosen version and source/device. Implement one small export proof-of-concept (trim-only first; then a basic effect if supported) and report limits.
- Keep preview and export behavior as close as practical, but document any effects that cannot be previewed/exported consistently. Media3 Composition documentation currently lists crossfading video/audio tracks as unsupported; do not claim a full professional NLE or CapCut-equivalent transition engine from Transformer alone.
- Make export cancellable and report progress/errors. Do not block the main/UI thread.

## Format support: do not promise “all formats”

- Validate with actual sample files. Container extension alone is not enough; codecs/profiles/bit depth and device decoder support matter.
- Treat standard MP4/H.264/AAC as a baseline target, then test MOV/HEVC, MKV/WebM, HDR/10-bit and other desired formats on the target devices.
- Do not add LibVLC automatically. If the real test set shows formats that Media3/device decoding cannot play, evaluate LibVLC as an optional **playback fallback**. Check artifact version, APK/ABI size, codec behavior, lifecycle and LGPL/third-party notices. LibVLC playback does not automatically make those files editable/exportable through Media3 Transformer.
- Do not add a blanket “all formats supported” claim. Add a capability/preflight layer and explicit unsupported-file feedback.

## RAW and MCRAW

- Do not claim Media3 or LibVLC can directly read MotionCam `.mcraw` files.
- Only add MCRAW support if the user confirms it is a product requirement. The reusable starting point is the separate Apache-2.0 `mirsadm/motioncam-decoder` C++ library. It is a decoder, not an editor UI, grading engine, timeline or export pipeline. Evaluate NDK/CMake integration, frame scheduling, GPU preview/rendering, audio synchronization, export, ABI and device performance.
- Do not transplant the whole `motioncam-app/motioncam-player` repository into the Android app without explicit approval: its GitHub project is marked work-in-progress, is a desktop-oriented Vulkan/GLFW/SDL2 executable, and is GPL-3.0. If the app is distributed as proprietary/closed source, obtain license review before using GPL code.
- Do not decompile or repackage the UNMCRAWSOME APK. Its releases repo is not an embeddable source SDK.

## Required validation and final report

Test on at least one target device and, when available, a lower-spec device:

1. SAF-selected MP4/H.264/AAC: open, play, pause, seek, resume, and leave/re-enter the screen.
2. A high-resolution or high-frame-rate file from the user's real workload.
3. MOV/HEVC, MKV/WebM, HDR/10-bit, or RAW files only if those are claimed targets.
4. Confirm audio sync, aspect ratio/rotation, URI permission persistence, memory use, and clean player release.
5. Run a trim export and verify the output plays; record unsupported cases accurately.
6. Run the existing unit/build/lint checks.

At completion, list changed files, dependency versions, device/format test results, known limitations, and any required third-party license notices. Do not silently vendor large binary libraries or change the timeline model without user approval.
