# Device and media test matrix

Run these against the app's real devices and sample footage before advertising format support.

## Playback tests

- [ ] SAF/document-picker `content://` MP4, H.264 video + AAC audio.
- [ ] Pause/resume, seek to start/middle/end, repeated scrubbing, and playback-speed changes.
- [ ] Leave/re-enter editor; rotate screen; background/foreground; release and recreate player without leaks.
- [ ] Correct orientation, aspect ratio, letterbox/crop behavior, audio sync, buffering and error UI.
- [ ] A high-resolution or high-frame-rate sample representative of users' footage.
- [ ] MOV/HEVC, MKV/WebM, VP9/AV1, 10-bit/HDR only when these are stated product targets.
- [ ] Every unsupported sample returns a visible diagnostic; no crash or indefinite spinner.

## Edit/export tests

- [ ] Trim-only export on a supported sample; check start/end, duration, A/V sync and output playability.
- [ ] Crop/rotate/scale/effect export if enabled; compare preview and output.
- [ ] Low-storage and cancellation/error paths.
- [ ] Export does not block UI; progress and final URI are reported.
- [ ] Test composition/transition limitations explicitly; do not claim crossfade if not implemented.

## Device coverage

At minimum, test the lowest supported Android API/device and one current mid-range device. If the app claims HDR, 10-bit, AV1, ProRes/DNxHR, MCRAW, or high-FPS editing, include a device and sample that actually exercise that feature. Save the device model, Android version, file metadata, selected backend and error logs with each result.
