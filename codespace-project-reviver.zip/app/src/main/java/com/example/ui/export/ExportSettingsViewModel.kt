package com.example.ui.export

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.timeline.core.TimelineProject
import com.example.timeline.export.backend.ExportBackendFactory
import com.example.timeline.export.model.*
import com.example.timeline.export.preset.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class ExportSettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val backendFactory = ExportBackendFactory(application)
    private val diagnostics = backendFactory.getDiagnostics()
    private val mediaCodecCaps = diagnostics.mediaCodecCapabilities
    private val ffmpegCaps = diagnostics.ffmpegCapabilities

    private val _uiState = MutableStateFlow(ExportSettingsUiState())
    val uiState: StateFlow<ExportSettingsUiState> = _uiState.asStateFlow()

    fun initProject(project: TimelineProject) {
        val initialSettings = ExportPresetManager.getSettingsForPreset(
            ExportPresetType.YOUTUBE_1080P, 
            project.id, 
            "ChromaPro_${project.name}_Export"
        )
        
        _uiState.update { 
            it.copy(
                project = project,
                currentSettings = initialSettings,
                selectedPreset = ExportPresetType.YOUTUBE_1080P
            )
        }
        validateSettings()
    }

    fun updateSettings(updater: (ExportSettings) -> ExportSettings) {
        _uiState.update {
            val newSettings = updater(it.currentSettings ?: return@update it)
            it.copy(
                currentSettings = newSettings,
                selectedPreset = ExportPresetType.CUSTOM
            )
        }
        validateSettings()
    }

    fun selectPreset(preset: ExportPresetType) {
        val project = _uiState.value.project ?: return
        val newSettings = ExportPresetManager.getSettingsForPreset(
            preset, 
            project.id, 
            _uiState.value.currentSettings?.outputFileName ?: "output"
        )
        _uiState.update {
            it.copy(
                currentSettings = newSettings,
                selectedPreset = preset
            )
        }
        validateSettings()
    }

    private fun validateSettings() {
        val settings = _uiState.value.currentSettings ?: return
        val codecVal = ExportCodecValidator.validate(settings.codec, settings.container, mediaCodecCaps, ffmpegCaps)
        val alphaVal = AlphaExportValidator.validate(settings.renderAlpha, settings.codec, settings.container, ffmpegCaps)
        val hdrVal = HdrExportValidator.validate(settings.exportHDR, settings.colorOutput, settings.codec, mediaCodecCaps, ffmpegCaps)

        val allErrors = codecVal.unsupportedFeatures + alphaVal.unsupportedFeatures + hdrVal.unsupportedFeatures
        val allWarnings = codecVal.warnings + alphaVal.warnings + hdrVal.warnings
        
        val validationResult = ExportValidationResult(
            isValid = allErrors.isEmpty(),
            unsupportedFeatures = allErrors,
            warnings = allWarnings,
            errorMessage = allErrors.firstOrNull()
        )

        // Estimated Size (Bitrate * Duration)
        // Assume default project duration for estimation, 10s for mock
        val durationSec = 10L
        val estimatedSizeMb = (settings.videoBitrate + settings.audioBitrate) * durationSec / (8 * 1024 * 1024f)

        _uiState.update {
            it.copy(
                validationResult = validationResult,
                estimatedSizeMb = estimatedSizeMb,
                estimatedRenderTimeSec = durationSec * 2
            )
        }
    }
}

data class ExportSettingsUiState(
    val project: TimelineProject? = null,
    val currentSettings: ExportSettings? = null,
    val selectedPreset: ExportPresetType = ExportPresetType.YOUTUBE_1080P,
    val validationResult: ExportValidationResult = ExportValidationResult(true, emptyList(), emptyList(), null),
    val estimatedSizeMb: Float = 0f,
    val estimatedRenderTimeSec: Long = 0L
)
