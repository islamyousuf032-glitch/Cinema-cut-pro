package com.example.timeline.export.backend

import android.content.Context
import com.example.timeline.core.TimelineProject
import com.example.timeline.export.model.*

class Media3TransformerBackend(private val context: Context) : ExportBackend {
    override val backendType = ExportBackendType.MEDIA3_TRANSFORMER

    override fun getCapabilities(): ExportBackendCapability {
        return ExportBackendCapability(
            backendAvailable = true,
            hardwareAccelerated = true,
            supportedCodecs = listOf(ExportCodec.H264, ExportCodec.H265),
            supportedContainers = listOf(ExportContainer.MP4),
            maxResolutionWidth = 3840,
            maxResolutionHeight = 2160,
            maxFps = 60f,
            supportsHDR = true,
            supportsAlpha = false,
            supportsAudioMix = false, // Media3 transformer audio mixing implies single track or sequence
            supportsVideoComposition = true,
            supportsProRes = false,
            supportsAV1 = false,
            supports10Bit = true,
            supportsBatch = false,
            supportsCancel = true
        )
    }

    override fun validate(settings: ExportSettings, project: TimelineProject): ExportValidationResult {
         val errors = mutableListOf<String>()
         val cap = getCapabilities()
         if (settings.codec !in cap.supportedCodecs) errors.add("Codec \${settings.codec} not supported by Media3 Transformer")
         if (settings.container !in cap.supportedContainers) errors.add("Container \${settings.container} not supported by Media3")
         return ExportValidationResult(errors.isEmpty(), errors, emptyList(), errors.firstOrNull())
    }

    override suspend fun prepare(job: ExportJob): Boolean = true

    override suspend fun render(job: ExportJob, onProgress: (ExportProgress) -> Unit) {
        onProgress(ExportProgress(job.jobId, ExportJobStatus.FAILED, 0f, 0, 0, 0, 0, "Media3 rendering deferred to ExportManager.", "Not Implemented"))
    }

    override fun cancel(jobId: String) {}

    override fun release() {}
}
