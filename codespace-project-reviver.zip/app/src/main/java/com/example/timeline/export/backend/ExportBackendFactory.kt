package com.example.timeline.export.backend

import android.content.Context

class ExportBackendFactory(private val context: Context) {

    fun createAllBackends(): List<ExportBackend> {
        return listOf(
            MediaCodecExportBackend(context),
            Media3TransformerBackend(context),
            NativeFfmpegExportBackend(),
            NativeSoftwareExportBackend()
        )
    }
    
    fun getDiagnostics(): ExportBackendDiagnostics {
        val backends = createAllBackends()
        val mediaCodec = backends.find { it.backendType == com.example.timeline.export.model.ExportBackendType.MEDIACODEC_HARDWARE }?.getCapabilities()
        val ffmpeg = backends.find { it.backendType == com.example.timeline.export.model.ExportBackendType.NATIVE_FFMPEG }?.getCapabilities()
        
        return ExportBackendDiagnostics(
            mediaCodecAvailable = mediaCodec?.backendAvailable ?: false,
            ffmpegNativeAvailable = ffmpeg?.backendAvailable ?: false,
            maxAvailableResolutionWidth = mediaCodec?.maxResolutionWidth ?: 0,
            maxAvailableResolutionHeight = mediaCodec?.maxResolutionHeight ?: 0,
            hardwareAv1Supported = mediaCodec?.supportsAV1 ?: false,
            availableCodecs = backends.flatMap { it.getCapabilities().supportedCodecs }.distinct().map { it.name },
            mediaCodecCapabilities = mediaCodec,
            ffmpegCapabilities = ffmpeg
        )
    }
}
