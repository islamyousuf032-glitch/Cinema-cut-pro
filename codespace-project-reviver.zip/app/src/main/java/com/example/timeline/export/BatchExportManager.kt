package com.example.timeline.export

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.timeline.export.backend.ExportBackendFactory
import com.example.timeline.export.backend.ExportBackendSelector
import com.example.timeline.export.model.ExportJob
import com.example.timeline.export.model.ExportJobStatus
import com.example.timeline.export.model.ExportSettings
import com.example.timeline.export.service.ExportCancelController
import com.example.timeline.export.service.ExportForegroundService
import com.example.timeline.export.service.ExportNotification
import com.example.timeline.export.service.ExportProgressRepository
import com.example.timeline.export.service.ExportState
import java.io.File
import com.example.timeline.core.TimelineProject
import com.example.timeline.export.backend.ExportBackend

object BatchExportManager {
    data class QueuedExport(
        val project: TimelineProject,
        val settings: ExportSettings,
        val outputFile: File
    )

    private val exportQueue = mutableListOf<QueuedExport>()
    var currentExport: QueuedExport? = null
    var currentBackend: ExportBackend? = null
    val queueState = kotlinx.coroutines.flow.MutableStateFlow<List<QueuedExport>>(emptyList())

    val exportState = ExportProgressRepository.exportState

    fun startExport(context: Context, project: TimelineProject, settings: ExportSettings, outputFile: File) {
        val job = QueuedExport(project, settings, outputFile)
        exportQueue.add(job)
        queueState.value = exportQueue.toList()

        if (exportState.value !is ExportState.Exporting) {
            startNextInQueue(context)
        }
    }

    private fun startNextInQueue(context: Context) {
        if (exportQueue.isEmpty()) return
        val next = exportQueue.removeAt(0)
        queueState.value = exportQueue.toList()
        currentExport = next

        ExportCancelController.reset()
        ExportProgressRepository.updateState(ExportState.Exporting("Preparing", 0, 1, 0f, 0L, 0L))

        val intent = Intent(context, ExportForegroundService::class.java).apply {
            action = "ACTION_START_EXPORT"
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun cancelExport(context: Context) {
        ExportCancelController.cancel()
        currentBackend?.cancel(currentExport?.settings?.exportId ?: "")
        currentBackend?.release()
        currentBackend = null
        
        ExportProgressRepository.updateState(ExportState.Idle)
        val intent = Intent(context, ExportForegroundService::class.java).apply {
            action = "ACTION_CANCEL_EXPORT"
        }
        context.startService(intent)

        exportQueue.clear()
        queueState.value = emptyList()
        currentExport = null
    }

    fun setIdle() {
        ExportProgressRepository.updateState(ExportState.Idle)
    }

    suspend fun runExportInternal(serviceContext: Context) {
        val export = currentExport ?: return
        val project = export.project
        val settings = export.settings
        val outputFile = export.outputFile
        val jobId = settings.exportId
        val startTimeMs = System.currentTimeMillis()

        try {
            // Validate Export before starting
            val validationErrors = com.example.timeline.export.validation.ExportValidator.validate(serviceContext, project, settings)
            if (validationErrors.isNotEmpty()) {
                val errorMsg = "Validation failed: \n" + validationErrors.joinToString("\n") { it.message }
                ExportProgressRepository.updateState(ExportState.Error(errorMsg))
                ExportNotification.showErrorNotification(serviceContext, "Export Validation Failed")
                onExportFinished(serviceContext)
                return
            }

            val factory = ExportBackendFactory(serviceContext)

            val selector = ExportBackendSelector(factory)
            
            val backend = selector.selectOptimalBackend(settings, project) ?: throw Exception("No suitable export backend found")
            currentBackend = backend
            
            val job = ExportJob(
                jobId = jobId,
                projectId = project.id,
                settings = settings,
                status = ExportJobStatus.QUEUED,
                outputUri = outputFile.absolutePath
            )

            val prepared = backend.prepare(job)
            if (!prepared) {
                val errorMsg = "Failed to prepare export backend"
                ExportProgressRepository.updateState(ExportState.Error(errorMsg))
                ExportNotification.showErrorNotification(serviceContext, errorMsg)
                return
            }

            var lastNotificationTime = 0L

            backend.render(job) { progress ->
                if (ExportCancelController.isCancelled) return@render

                val now = System.currentTimeMillis()
                val elapsedMs = now - startTimeMs
                
                val percentFinished = progress.progressPercent / 100f
                val estimatedRemaining = if (percentFinished > 0) {
                    ((elapsedMs / percentFinished) - elapsedMs).toLong()
                } else 0L

                val stageString = when (progress.status) {
                    ExportJobStatus.RENDERING_VIDEO -> "Rendering Video"
                    ExportJobStatus.RENDERING_AUDIO -> "Rendering Audio"
                    ExportJobStatus.ENCODING -> "Encoding"
                    ExportJobStatus.MUXING -> "Muxing"
                    else -> "Processing"
                }

                if (progress.status == ExportJobStatus.COMPLETED) {
                    ExportProgressRepository.updateState(ExportState.Completed(outputFile))
                    ExportNotification.showCompletedNotification(serviceContext, outputFile)
                    onExportFinished(serviceContext)
                } else if (progress.status == ExportJobStatus.FAILED) {
                    val errorMsg = progress.errorMessage ?: "Export failed"
                    ExportProgressRepository.updateState(ExportState.Error(errorMsg))
                    ExportNotification.showErrorNotification(serviceContext, errorMsg)
                    onExportFinished(serviceContext)
                } else {
                    ExportProgressRepository.updateState(
                        ExportState.Exporting(
                            stage = stageString,
                            renderedFrames = progress.renderedFrames,
                            totalFrames = progress.totalFrames,
                            percent = percentFinished,
                            elapsedMs = elapsedMs,
                            estimatedRemainingMs = estimatedRemaining
                        )
                    )

                    // Throttle notification updates (e.g., every 500ms)
                    if (now - lastNotificationTime > 500) {
                        ExportNotification.updateProgress(
                            serviceContext, 
                            progress.progressPercent.toInt(), 
                            "$stageString ${progress.progressPercent.toInt()}%"
                        )
                        lastNotificationTime = now
                    }
                }
            }
        } catch (e: Exception) {
            val mappedError = com.example.timeline.export.validation.ExportErrorMapper.mapExceptionToError(e)
            val recoveryActions = com.example.timeline.export.validation.ExportErrorMapper.getRecoveryActions(mappedError)
            
            Log.e("BatchExportManager", "Export failed: \${mappedError.message}", mappedError.exception)
            
            val errorMsg = mappedError.message + if (recoveryActions.isNotEmpty()) {
                "\n\nSuggested actions:\n" + recoveryActions.joinToString("\n") { "- " + it.name.replace('_', ' ') }
            } else ""

            ExportProgressRepository.updateState(ExportState.Error(errorMsg))
            ExportNotification.showErrorNotification(serviceContext, "Export Failed")
            onExportFinished(serviceContext)
        } finally {
            currentBackend?.release()
            currentBackend = null
        }
    }

    private fun onExportFinished(context: Context) {
        currentExport = null
        if (exportQueue.isNotEmpty()) {
            startNextInQueue(context)
        } else {
            val intent = Intent(context, ExportForegroundService::class.java).apply {
                action = "ACTION_CANCEL_EXPORT"
            }
            context.startService(intent)
        }
    }
}
