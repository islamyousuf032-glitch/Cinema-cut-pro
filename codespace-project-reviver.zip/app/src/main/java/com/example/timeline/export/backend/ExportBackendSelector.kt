package com.example.timeline.export.backend

import com.example.timeline.core.TimelineProject
import com.example.timeline.export.model.ExportBackendType
import com.example.timeline.export.model.ExportSettings

class ExportBackendSelector(private val factory: ExportBackendFactory) {

    fun selectOptimalBackend(settings: ExportSettings, project: TimelineProject): ExportBackend? {
        val allBackends = factory.createAllBackends()
        
        // Filter those natively available
        val availableBackends = allBackends.filter { it.getCapabilities().backendAvailable }
        if (availableBackends.isEmpty()) return null
        
        // Priority 1: User requested hardware and MediaCodec combo fits
        if (settings.useHardwareEncoder) {
            val mediaCodecBackend = availableBackends.find { it.backendType == ExportBackendType.MEDIACODEC_HARDWARE }
            if (mediaCodecBackend != null && mediaCodecBackend.validate(settings, project).isValid) {
                return mediaCodecBackend
            }
            
            // Fallback to media3 transformer if it works
            val media3Backend = availableBackends.find { it.backendType == ExportBackendType.MEDIA3_TRANSFORMER }
            if (media3Backend != null && media3Backend.validate(settings, project).isValid) {
                return media3Backend
            }
        }
        
        // Priority 2: FFmpeg for complex stuff (ProRes, MKV, advanced audio/alpha)
        val ffmpegBackend = availableBackends.find { it.backendType == ExportBackendType.NATIVE_FFMPEG }
        if (ffmpegBackend != null && ffmpegBackend.validate(settings, project).isValid) {
            return ffmpegBackend
        }
        
        // Fallback: whatever returns true from validate
        for (backend in availableBackends) {
            if (backend.validate(settings, project).isValid) return backend
        }
        
        // If FFmpeg is missing but required:
        val ffmpegCheck = allBackends.find { it.backendType == ExportBackendType.NATIVE_FFMPEG }
        if (ffmpegCheck != null && !ffmpegCheck.getCapabilities().backendAvailable) {
            // we could return it just to show the error via validation
            return ffmpegCheck
        }
        
        return null
    }
}
