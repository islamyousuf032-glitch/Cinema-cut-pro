#include "color_eval.h"
#include <algorithm>

void ColorEval::applyColorAdjustments(RenderFrame& frame, float exposure, float brightness, float contrast, float saturation) {
    if (!frame.buffer || frame.format != 0) return; // Only RGBA

    int totalPixels = frame.width * frame.height;
    
    // simple contrast/brightness stub
    for (int i = 0; i < totalPixels; ++i) {
        for (int c = 0; c < 3; ++c) {
            float v = frame.buffer[i * 4 + c] / 255.0f;
            // Contrast
            v = ((v - 0.5f) * contrast) + 0.5f;
            // Brightness
            v += brightness;
            // Clamp
            if (v < 0.0f) v = 0.0f;
            if (v > 1.0f) v = 1.0f;
            frame.buffer[i * 4 + c] = (uint8_t)(v * 255.0f);
        }
    }
}
