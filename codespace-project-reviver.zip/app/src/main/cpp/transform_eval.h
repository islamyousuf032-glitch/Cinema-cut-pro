#ifndef TRANSFORM_EVAL_H
#define TRANSFORM_EVAL_H

#include "render_frame.h"

class TransformEval {
public:
    static void applyTransform(RenderFrame& frame, float scaleX, float scaleY, float rotation, float posX, float posY, float opacity);
};

#endif // TRANSFORM_EVAL_H
