#ifndef COLOR_EVAL_H
#define COLOR_EVAL_H

#include "render_frame.h"

class ColorEval {
public:
    static void applyColorAdjustments(RenderFrame& frame, float exposure, float brightness, float contrast, float saturation);
};

#endif // COLOR_EVAL_H
