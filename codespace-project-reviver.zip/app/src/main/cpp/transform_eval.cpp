#include "transform_eval.h"
#include <cmath>

void TransformEval::applyTransform(RenderFrame& frame, float scaleX, float scaleY, float rotation, float posX, float posY, float opacity) {
    // Basic implementation for transformation
    // In a full implementation, this applies affine transformations to the frame buffer.
    // Assuming RGBA mapping here.
    if (!frame.buffer || frame.width == 0 || frame.height == 0) return;
    
    // Stub implementation: applies opacity
    if (opacity < 1.0f && frame.format == 0) { // RGBA
        int totalPixels = frame.width * frame.height;
        for (int i = 0; i < totalPixels; ++i) {
            frame.buffer[i * 4 + 3] = (uint8_t)(frame.buffer[i * 4 + 3] * opacity);
        }
    }
}
