#ifndef FRAME_COMPOSITOR_H
#define FRAME_COMPOSITOR_H

#include "render_frame.h"

class FrameCompositor {
public:
    static void compositeFrames(RenderFrame& bgFrame, const RenderFrame& fgFrame, int blendMode);
    static void convertRgbaToYuv420(const RenderFrame& rgbaFrame, RenderFrame& yuvFrame);
};

#endif // FRAME_COMPOSITOR_H
