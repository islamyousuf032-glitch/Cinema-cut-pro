#ifndef RENDER_FRAME_H
#define RENDER_FRAME_H

#include <cstdint>

struct RenderFrame {
    uint8_t* buffer;
    int width;
    int height;
    int stride;
    int format; // 0: RGBA, 1: YUV420
};

#endif // RENDER_FRAME_H
