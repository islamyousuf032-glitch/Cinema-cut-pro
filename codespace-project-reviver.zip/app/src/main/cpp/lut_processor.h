#ifndef LUT_PROCESSOR_H
#define LUT_PROCESSOR_H

#include "render_frame.h"

class LUTProcessor {
public:
    static void applyLUT(RenderFrame& frame, const uint8_t* lutData, int lutSize);
};

#endif // LUT_PROCESSOR_H
