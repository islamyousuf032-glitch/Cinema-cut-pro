#include <jni.h>
#include "export_core.h"
#include "transform_eval.h"
#include "color_eval.h"
#include "lut_processor.h"
#include "frame_compositor.h"
#include "audio_mixer.h"
#include <android/log.h>

#define LOG_TAG "NativeExportJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static ExportCore* exportCoreInstance = nullptr;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeCreateExportCore(JNIEnv *env, jobject thiz) {
    if (!exportCoreInstance) {
        exportCoreInstance = new ExportCore();
        LOGI("Created ExportCore instance");
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeReleaseExportCore(JNIEnv *env, jobject thiz) {
    if (exportCoreInstance) {
        delete exportCoreInstance;
        exportCoreInstance = nullptr;
        LOGI("Released ExportCore instance");
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeEvaluateFramePlan(JNIEnv *env, jobject thiz, jlong frameIndex) {
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeApplyTransform(JNIEnv *env, jobject thiz, jobject buffer, jint width, jint height, jfloat scaleX, jfloat scaleY, jfloat rotation, jfloat posX, jfloat posY, jfloat opacity) {
    uint8_t* ptr = (uint8_t*)env->GetDirectBufferAddress(buffer);
    if (!ptr) return;
    RenderFrame frame = {ptr, width, height, width * 4, 0};
    TransformEval::applyTransform(frame, scaleX, scaleY, rotation, posX, posY, opacity);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeApplyColor(JNIEnv *env, jobject thiz, jobject buffer, jint width, jint height, jfloat exposure, jfloat brightness, jfloat contrast, jfloat saturation) {
    uint8_t* ptr = (uint8_t*)env->GetDirectBufferAddress(buffer);
    if (!ptr) return;
    RenderFrame frame = {ptr, width, height, width * 4, 0};
    ColorEval::applyColorAdjustments(frame, exposure, brightness, contrast, saturation);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeCompositeFrame(JNIEnv *env, jobject thiz, jobject bgBuffer, jobject fgBuffer, jint width, jint height, jint blendMode) {
    uint8_t* bgPtr = (uint8_t*)env->GetDirectBufferAddress(bgBuffer);
    uint8_t* fgPtr = (uint8_t*)env->GetDirectBufferAddress(fgBuffer);
    if (!bgPtr || !fgPtr) return;
    RenderFrame bgFrame = {bgPtr, width, height, width * 4, 0};
    RenderFrame fgFrame = {fgPtr, width, height, width * 4, 0};
    FrameCompositor::compositeFrames(bgFrame, fgFrame, blendMode);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeConvertRgbaToYuv420(JNIEnv *env, jobject thiz, jobject rgbaBuffer, jobject yuvBuffer, jint width, jint height) {
    uint8_t* rgbaPtr = (uint8_t*)env->GetDirectBufferAddress(rgbaBuffer);
    uint8_t* yuvPtr = (uint8_t*)env->GetDirectBufferAddress(yuvBuffer);
    if (!rgbaPtr || !yuvPtr) return;
    RenderFrame rgbaFrame = {rgbaPtr, width, height, width * 4, 0};
    RenderFrame yuvFrame = {yuvPtr, width, height, width, 1};
    FrameCompositor::convertRgbaToYuv420(rgbaFrame, yuvFrame);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeMixAudio(JNIEnv *env, jobject thiz, jobject destBuffer, jobject srcBuffer, jint numSamples, jfloat volume) {
    int16_t* destPtr = (int16_t*)env->GetDirectBufferAddress(destBuffer);
    int16_t* srcPtr = (int16_t*)env->GetDirectBufferAddress(srcBuffer);
    if (!destPtr || !srcPtr) return;
    AudioMixer::mixAudio(destPtr, srcPtr, numSamples, volume);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeBlendWatermarkYuv(JNIEnv *env, jobject thiz, jobject yuvBuffer, jobject watermarkRgbaBuffer, jint width, jint height) {
    // Stub for blending RGBA watermark into YUV buffer
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_example_timeline_export_native_NativeExportCore_nativeGetStats(JNIEnv *env, jobject thiz) {
    jintArray result = env->NewIntArray(3);
    if (exportCoreInstance) {
        ExportStats stats = exportCoreInstance->getStats();
        jint fill[3] = {stats.framesProcessed, (jint)stats.totalRenderTimeMs, stats.audioSamplesMixed};
        env->SetIntArrayRegion(result, 0, 3, fill);
    } else {
        jint fill[3] = {0, 0, 0};
        env->SetIntArrayRegion(result, 0, 3, fill);
    }
    return result;
}
