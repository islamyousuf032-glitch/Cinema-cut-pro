#include "frame_compositor.h"

void FrameCompositor::compositeFrames(RenderFrame& bgFrame, const RenderFrame& fgFrame, int blendMode) {
    // Stub
}

void FrameCompositor::convertRgbaToYuv420(const RenderFrame& rgbaFrame, RenderFrame& yuvFrame) {
    // Stub
}
