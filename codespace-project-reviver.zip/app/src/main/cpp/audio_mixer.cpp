#include "audio_mixer.h"

void AudioMixer::mixAudio(int16_t* dest, const int16_t* src, int numSamples, float volume) {
    for (int i = 0; i < numSamples; ++i) {
        float sample = dest[i] + src[i] * volume;
        if (sample > 32767.0f) sample = 32767.0f;
        if (sample < -32768.0f) sample = -32768.0f;
        dest[i] = (int16_t)sample;
    }
}
