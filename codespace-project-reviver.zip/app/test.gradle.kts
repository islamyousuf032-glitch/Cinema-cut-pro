tasks.register("checkDep") {
    doLast {
        val url = java.net.URL("https://repo1.maven.org/maven2/com/arthenica/ffmpeg-kit-full/")
        val connection = url.openConnection() as java.net.HttpURLConnection
        connection.requestMethod = "GET"
        if (connection.responseCode == 200) {
            println("Response: " + connection.inputStream.reader().readText())
        } else {
            println("Failed: " + connection.responseCode)
        }
    }
}
